<?php
session_start();
require_once 'database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

$username = $_SESSION['email'];

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid book ID.");
}

$book_id = intval($_GET['id']);

$stmt = $conn->prepare("SELECT * FROM books WHERE id = ?");
$stmt->bind_param("i", $book_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Book not found.");
}

$book = $result->fetch_assoc();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Book Details</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f4f4f4;
      margin: 0;
      padding: 0;
    }
    .header {
      background: linear-gradient(135deg, #667eea, #764ba2);
      color: #fff;
      padding: 20px;
      text-align: center;
      position: relative;
    }
    .header a {
      position: absolute;
      left: 20px;
      top: 20px;
      background: #fff;
      color: #764ba2;
      text-decoration: none;
      padding: 8px 16px;
      border-radius: 5px;
      font-weight: bold;
    }
    .container {
      width: 90%;
      max-width: 1100px;
      margin: 30px auto;
      background: #fff;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    .book-details {
      display: flex;
      flex-wrap: wrap;
      gap: 30px;
    }
    .book-image img {
      width: 100%;
      max-width: 300px;
      border-radius: 6px;
    }
    .book-info {
      flex: 1;
    }
    .book-info h2 {
      margin-top: 0;
      font-size: 2.2em;
    }
    .book-info p {
      margin: 8px 0;
      font-size: 1.1em;
    }
    .description {
      margin-top: 20px;
      background: #f9f9f9;
      padding: 15px;
      border-left: 5px solid #764ba2;
      border-radius: 4px;
    }
    .buttons {
      margin-top: 25px;
    }
    .buttons a {
      display: inline-block;
      text-decoration: none;
      background: #764ba2;
      color: #fff;
      padding: 10px 18px;
      border-radius: 5px;
      margin-right: 10px;
      font-size: 1em;
      transition: background 0.3s;
    }
    .buttons a:hover {
      background: #667eea;
    }
  </style>
</head>
<body>

<div class="header">
  <a href="home.php">← Home</a>
  <h1>Book Details</h1>
</div>

<div class="container">
  <div class="book-details">
    <!-- Book Image -->
    <div class="book-image">
      <?php if (!empty($book['cover'])): ?>
        <img src="uploads/covers/<?= htmlspecialchars($book['cover']) ?>" alt="Book Cover">
      <?php else: ?>
        <div style="width:300px;height:400px;background:#eee;display:flex;align-items:center;justify-content:center;">No Image</div>
      <?php endif; ?>
    </div>

    <!-- Book Info -->
    <div class="book-info">
      <h2><?= htmlspecialchars($book['title']) ?></h2>
      <p><strong>Author:</strong> <?= htmlspecialchars($book['author']) ?></p>
      <p><strong>Genre:</strong> <?= htmlspecialchars($book['genre']) ?></p>
      <p><strong>ISBN:</strong> <?= htmlspecialchars($book['isbn']) ?></p>
      <p><strong>Available:</strong> <?= $book['quantity'] ?></p>

      <div class="description">
        <h3>Description</h3>
        <p><?= nl2br(htmlspecialchars($book['description'])) ?></p>
      </div>

      <!-- Action Buttons -->
      <div class="buttons">
        <a href="borrow.php?book_id=<?= $book['id'] ?>">Borrow This Book</a>
        <?php if (!empty($book['pdf'])): ?>
            <a href="uploads/pdfs/<?= urlencode($book['pdf']) ?>" target="_blank">Read Online</a>
        <?php else: ?>
          <a href="#" onclick="alert('No PDF available for this book.'); return false;">Read Online</a>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

</body>
</html>
