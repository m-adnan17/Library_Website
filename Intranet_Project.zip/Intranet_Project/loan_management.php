<?php
session_start();
require_once 'database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

$user_id = $_SESSION['user_id'];

// Handle return request
if ($_SERVER['REQUEST_METHOD'] === "POST" && isset($_POST['return_book'])) {
    $loan_id = (int) $_POST['loan_id'];
    $book_id = (int) $_POST['book_id'];

    // Mark loan as returned
    $stmt = $conn->prepare("UPDATE loans SET returned = 1 WHERE id = ?");
    $stmt->bind_param("i", $loan_id);
    $stmt->execute();
    $stmt->close();

    // Increase book quantity
    $stmt = $conn->prepare("UPDATE books SET quantity = quantity + 1 WHERE id = ?");
    $stmt->bind_param("i", $book_id);
    $stmt->execute();
    $stmt->close();

    $_SESSION['message'] = "Book returned successfully!";
    header("Location: borrowed_books.php");
    exit();
}

// Fetch borrowed books
$stmt = $conn->prepare("
    SELECT loans.id AS loan_id, books.id AS book_id, books.title, books.author, loans.due_date 
    FROM loans 
    JOIN books ON loans.book_id = books.id 
    WHERE loans.user_id = ? AND loans.returned = 0
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$loans_result = $stmt->get_result();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Borrowed Books</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: #fff;
            min-height: 100vh;
        }
        .container {
            margin-top: 40px;
        }
        .card {
            background: #fff;
            border-radius: 12px;
            padding: 25px;
            color: #333;
            box-shadow: 0 10px 20px rgba(0,0,0,0.2);
        }
        .table thead {
            background: #667eea;
            color: #fff;
        }
        .btn-return {
            background: #ff4b5c;
            border: none;
            color: #fff;
        }
        .btn-return:hover {
            background: #e63e4e;
        }
        .alert {
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div id="navbar-placeholder"></div>

    

        
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        fetch("home.php")
            .then(response => response.text())
            .then(data => document.getElementById("navbar-placeholder").innerHTML = data);
    </script>
</body>
</html>
