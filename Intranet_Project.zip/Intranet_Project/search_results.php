<?php
session_start();
require_once 'database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.html");
    exit();
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'] ?? $_SESSION['email'];

// Handle Borrow Request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book_id'])) {
    $bookId = intval($_POST['book_id']);

    $stmt = $conn->prepare("SELECT quantity FROM books WHERE id = ?");
    $stmt->bind_param("i", $bookId);
    $stmt->execute();
    $book = $stmt->get_result()->fetch_assoc();

    if ($book && $book['quantity'] > 0) {
        $checkBorrow = $conn->prepare("SELECT id FROM borrowed_books WHERE user_id = ? AND book_id = ? AND returned_at IS NULL");
        $checkBorrow->bind_param("ii", $user_id, $bookId);
        $checkBorrow->execute();
        $checkBorrow->store_result();

        if ($checkBorrow->num_rows === 0) {
            $dueDate = date('Y-m-d', strtotime('+7 days'));
            $insert = $conn->prepare("INSERT INTO borrowed_books (user_id, book_id, due_date) VALUES (?, ?, ?)");
            $insert->bind_param("iis", $user_id, $bookId, $dueDate);
            $insert->execute();

            $update = $conn->prepare("UPDATE books SET quantity = quantity - 1 WHERE id = ?");
            $update->bind_param("i", $bookId);
            $update->execute();

            header("Location: user_dashboard.php");
            exit();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Search Results</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f2f2f2;
      margin: 0;
      padding: 0;
    }
    header {
      background: linear-gradient(135deg, #567f38, #764ba2);
      color: #fff;
      padding: 25px 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .logo {
      font-size: 1.5em;
      font-weight: bold;
    }
    .user-actions span {
      font-weight: bold;
    }
    .user-actions button {
      margin-left: 10px;
      padding: 10px 12px;
      border: none;
      border-radius: 3px;
      background-color: #fff;
      color: #764ba2;
      font-weight: bold;
      cursor: pointer;
    }
    .container {
      max-width: 1200px;
      margin: 30px auto;
      padding: 20px;
      background-color: #fff;
      border-radius: 8px;
    }
    h2 {
      margin-bottom: 20px;
      color: #333;
    }
    .book-list {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
    }
    .book-item {
      width: 280px;
      background-color: #f9f9f9;
      padding: 15px;
      border-radius: 5px;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }
    .book-item img {
      width: 100%;
      height: 400px;
      object-fit: cover;
      border-radius: 5px;
    }
    .book-item h3 {
      margin: 10px 0 5px;
      color: #333;
    }
    .book-item p {
      margin: 5px 0;
      font-size: 0.95em;
    }
    .book-item form button {
      margin-top: 10px;
      padding: 12px 18px;
      border: none;
      border-radius: 3px;
      background-color: #667eea;
      color: #fff;
      cursor: pointer;
    }
  </style>
</head>
<body>

<header>
  <div class="logo">Ocean Library</div>
  <div class="user-actions">
    <span>Welcome, <?= htmlspecialchars(ucfirst($username)) ?></span>
    <button onclick="location.href='home.php'">Home</button>
    <button onclick="location.href='logout.php'">Logout</button>
  </div>
</header>

<div class="container">
<?php
if (isset($_GET['search']) && !empty(trim($_GET['search']))) {
    $searchTerm = "%" . trim($_GET['search']) . "%";

    $stmt = $conn->prepare("SELECT * FROM books WHERE title LIKE ? OR author LIKE ? OR genre LIKE ?");
    $stmt->bind_param("sss", $searchTerm, $searchTerm, $searchTerm);
    $stmt->execute();
    $results = $stmt->get_result();

    echo "<h2>Search Results for: \"" . htmlspecialchars($_GET['search']) . "\"</h2>";

    if ($results->num_rows > 0) {
        echo "<div class='book-list'>";
        while ($book = $results->fetch_assoc()) {
            echo "<div class='book-item'>";
            if (!empty($book['cover'])) {
                echo "<img src='uploads/covers/" . htmlspecialchars($book['cover']) . "' alt='Book Cover'>";
            } else {
                echo "<div style='width:100%; height:200px; background-color:#eee; display:flex; align-items:center; justify-content:center;'>No Cover</div>";
            }

            echo "<h3>" . htmlspecialchars($book['title']) . "</h3>";
            echo "<p><strong>Author:</strong> " . htmlspecialchars($book['author']) . "</p>";
            echo "<p><strong>Genre:</strong> " . htmlspecialchars($book['genre']) . "</p>";
            echo "<p><strong>ISBN:</strong> " . htmlspecialchars($book['isbn']) . "</p>";
            echo "<p><strong>Available:</strong> " . $book['quantity'] . "</p>";

            echo "<form method='POST' action=''>
                    <input type='hidden' name='book_id' value='" . $book['id'] . "'>
                    <button type='submit'>Borrow</button>
                  </form>";

            if (!empty($book['pdf'])) {
                echo "<form method='GET' action='uploads/pdfs/" . urlencode($book['pdf']) . "' target='_blank'>
                        <button type='submit'>Read Online</button>
                      </form>";
            } else {
                echo "<button disabled>No PDF</button>";
            }

            echo "</div>";
        }
        echo "</div>";
    } else {
        echo "<p>No books found matching your search.</p>";
    }
} else {
    echo "<p>No search query provided.</p>";
}
?>
</div>

</body>
</html>
