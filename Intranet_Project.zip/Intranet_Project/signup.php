<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once 'database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirmPassword'] ?? '';

    if (empty($username) || empty($email) || empty($password) || empty($confirmPassword)) {
        die("Error: Please fill in all fields.");
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Error: Invalid email format.");
    }

    if ($password !== $confirmPassword) {
        die("Error: Passwords do not match.");
    }

    try {
        if (!$conn) {
            throw new Exception("Database connection failed: " . mysqli_connect_error());
        }

        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        if (!$stmt) {
            die("SQL Error: " . $conn->error);
        }
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            die("Error: Username or email already exists.");
        }
        $stmt->close();

        // Secure password hashing
        $hashedPassword = password_hash($password, PASSWORD_ARGON2ID);
        if (!$hashedPassword) {
            die("Error: Password hashing failed.");
        }

        $role = 'user';

        $stmt = $conn->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
        if (!$stmt) {
            die("SQL Error: " . $conn->error);
        }
        $stmt->bind_param("ssss", $username, $email, $hashedPassword, $role);

        if ($stmt->execute()) {
            echo "<script>alert('Registration successful! Redirecting to login.'); window.location.href='login.html';</script>";
            exit();
        } else {
            throw new Exception("Execute failed: " . $stmt->error);
        }

    } catch (Exception $e) {
        die("Database Error: " . $e->getMessage());
    }

    $stmt->close();
    $conn->close();
} else {
    header("Location: signup.html");
    exit();
}
?>
