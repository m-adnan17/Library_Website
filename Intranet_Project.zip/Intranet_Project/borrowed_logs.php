<?php
session_start();
require_once 'database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

$query = $conn->query("
    SELECT bb.id, bb.borrowed_at, bb.due_date, bb.returned_at,
           b.title AS book_title,
           u.username AS user_name, u.email
    FROM borrowed_books bb
    JOIN books b ON bb.book_id = b.id
    JOIN users u ON bb.user_id = u.id
    ORDER BY bb.borrowed_at DESC
");
?>

<!DOCTYPE html>
<html>
<head>
  <title>Borrowed Book Logs</title>
  <style>
    body { font-family: Arial, sans-serif; padding: 20px; background: #567f38; }
    h2 { margin-bottom: 20px; }
    table { width: 100%; border-collapse: collapse; background: white; }
    th, td { padding: 10px; border: 1px solid #ccc; text-align: left; }
    th { background-color: #3f51b5; color: white; }
    .status-returned { color: green; }
    .status-overdue { color: red; font-weight: bold; }
    .status-borrowed { color: #e67e22; }
    .btn { text-decoration: none; padding: 10px 15px; background: #3f51b5; color: white; border-radius: 5px; }
    .btn:hover { background: #303f9f; }
  </style>
</head>
<body>

<h2>Borrowed Book Logs</h2>
<a href="admin_dashboard.php" class="btn">← Back to Dashboard</a>
<br><br>

<table>
  <tr>
    <th>Book Title</th>
    <th>User</th>
    <th>Email</th>
    <th>Borrowed At</th>
    <th>Due Date</th>
    <th>Returned At</th>
    <th>Status</th>
  </tr>

  <?php while ($log = $query->fetch_assoc()): ?>
    <?php
      $status = '';
      if ($log['returned_at']) {
          $status = '<span class="status-returned">Returned</span>';
      } elseif (strtotime($log['due_date']) < time()) {
          $status = '<span class="status-overdue">Overdue</span>';
      } else {
          $status = '<span class="status-borrowed">Borrowed</span>';
      }
    ?>
    <tr>
      <td><?= htmlspecialchars($log['book_title']) ?></td>
      <td><?= htmlspecialchars($log['user_name']) ?></td>
      <td><?= htmlspecialchars($log['email']) ?></td>
      <td><?= $log['borrowed_at'] ?></td>
      <td><?= $log['due_date'] ?></td>
      <td><?= $log['returned_at'] ?? '-' ?></td>
      <td><?= $status ?></td>
    </tr>
  <?php endwhile; ?>
</table>

</body>
</html>
