<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

require 'database.php';

// Handle user deletion
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    header("Location: user_management.php");
    exit();
}

// Fetch users
$users = [];
$result = $conn->query("SELECT * FROM users ORDER BY username ASC");
if ($result) {
    $users = $result->fetch_all(MYSQLI_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>User Management</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f7f9fb;
    }

    header {
      background-color: #567f38;
      color: white;
      padding: 20px;
      text-align: center;
    }

    .container {
      max-width: 1100px;
      margin: 30px auto;
      padding: 20px;
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.05);
    }

    h2, h3 {
      color: #333;
    }

    .btn {
      padding: 8px 14px;
      background-color: #4CAF50;
      color: white;
      border: none;
      border-radius: 4px;
      text-decoration: none;
      font-size: 14px;
      cursor: pointer;
    }

    .btn:hover {
      background-color: #45a049;
    }

    .btn.danger {
      background-color: #e74c3c;
    }

    .btn.danger:hover {
      background-color: #c0392b;
    }

    form {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 10px;
      margin-bottom: 30px;
    }

    form input, form button {
      padding: 10px;
      font-size: 14px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }

    table th, table td {
      border: 1px solid #ddd;
      padding: 12px;
      text-align: left;
    }

    table th {
      background-color: #f0f0f0;
    }

    .actions a {
      margin-right: 8px;
    }

    .top-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 30px;
    }

    @media (max-width: 600px) {
      form {
        grid-template-columns: 1fr;
      }

      .top-bar {
        flex-direction: column;
        gap: 10px;
      }
    }
  </style>
</head>
<body>

<header>
  <h1>Admin Panel - User Management</h1>
</header>

<div class="container">
  <div class="top-bar">
    <h2>Manage Users</h2>
    <a href="admin_dashboard.php" class="btn">⬅ Back to Dashboard</a>
  </div>

  <h3>Add New User</h3>
  <form action="add_user.php" method="POST">
    <input type="text" name="username" placeholder="Username" required>
    <input type="email" name="email" placeholder="Email" required>
    <input type="text" name="role" placeholder="Role (admin/user)" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit" class="btn">Add User</button>
  </form>

  <h3>Registered Users</h3>
  <table>
    <thead>
      <tr>
        <th>Username</th>
        <th>Email</th>
        <th>Role</th>
        <th style="text-align:center;">Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($users as $user): ?>
      <tr>
        <td><?= htmlspecialchars($user['username']) ?></td>
        <td><?= htmlspecialchars($user['email']) ?></td>
        <td><?= htmlspecialchars($user['role']) ?></td>
        <td class="actions" style="text-align:center;">
          <a href="edit_user.php?id=<?= $user['id'] ?>" class="btn">Edit</a>
          <a href="?delete=<?= $user['id'] ?>" class="btn danger" onclick="return confirm('Delete this user?');">Delete</a>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

</body>
</html>
