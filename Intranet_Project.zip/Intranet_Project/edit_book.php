<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

require 'database.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: book_management.php");
    exit();
}

$book_id = (int) $_GET['id'];

// Fetch book
$stmt = $conn->prepare("SELECT * FROM books WHERE id = ?");
$stmt->bind_param("i", $book_id);
$stmt->execute();
$result = $stmt->get_result();
$book = $result->fetch_assoc();
$stmt->close();

if (!$book) {
    header("Location: book_management.php");
    exit();
}

// Handle update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $author = $_POST['author'];
    $isbn = $_POST['isbn'];
    $genre = $_POST['genre'];
    $quantity = (int) $_POST['quantity'];
    $description = $_POST['description'];

    $cover = $book['cover'];
    $pdf = $book['pdf'];

    // Cover upload
    if (!empty($_FILES['cover']['name'])) {
        $cover = basename($_FILES['cover']['name']);
        move_uploaded_file($_FILES['cover']['tmp_name'], "uploads/covers/$cover");
    }

    // PDF upload
    if (!empty($_FILES['pdf']['name'])) {
        $pdf = basename($_FILES['pdf']['name']);
        move_uploaded_file($_FILES['pdf']['tmp_name'], "uploads/pdfs/$pdf");
    }

    $stmt = $conn->prepare("UPDATE books SET title = ?, author = ?, isbn = ?, genre = ?, quantity = ?, description = ?, cover = ?, pdf = ? WHERE id = ?");
    $stmt->bind_param("ssssisssi", $title, $author, $isbn, $genre, $quantity, $description, $cover, $pdf, $book_id);
    $stmt->execute();
    $stmt->close();

    header("Location: book_management.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Book</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 40px; }
    form { max-width: 600px; margin: auto; background: #f9f9f9; padding: 20px; border-radius: 8px; }
    input, textarea { width: 100%; margin-bottom: 15px; padding: 8px; font-size: 16px; }
    button { padding: 10px 20px; background: #667eea; color: white; border: none; border-radius: 4px; cursor: pointer; }
    button:hover { background: #564fc8; }
    .preview { margin-bottom: 15px; }
    .preview img { width: 120px; }
    a.back { display: inline-block; margin-bottom: 20px; text-decoration: none; color: #667eea; }
  </style>
</head>
<body>

<a href="book_management.php" class="back">← Back to Book Management</a>
<h2>Edit Book</h2>

<form action="edit_book.php?id=<?= $book_id ?>" method="POST" enctype="multipart/form-data">
  <input type="text" name="title" value="<?= htmlspecialchars($book['title']) ?>" placeholder="Title" required>
  <input type="text" name="author" value="<?= htmlspecialchars($book['author']) ?>" placeholder="Author" required>
  <input type="text" name="isbn" value="<?= htmlspecialchars($book['isbn']) ?>" placeholder="ISBN" required>
  <input type="text" name="genre" value="<?= htmlspecialchars($book['genre']) ?>" placeholder="Genre" required>
  <input type="number" name="quantity" value="<?= $book['quantity'] ?>" placeholder="Quantity" required>

  <label>Description</label>
  <textarea name="description" rows="4"><?= htmlspecialchars($book['description']) ?></textarea>

  <label>Current Cover:</label>
  <div class="preview">
    <?php if (!empty($book['cover'])): ?>
      <img src="uploads/covers/<?= htmlspecialchars($book['cover']) ?>" alt="Cover">
    <?php else: ?>
      <em>No cover uploaded</em>
    <?php endif; ?>
  </div>
  <input type="file" name="cover" accept="image/*">

  <label>Current PDF:</label>
  <div class="preview">
    <?php if (!empty($book['pdf'])): ?>
      <a href="uploads/pdfs/<?= htmlspecialchars($book['pdf']) ?>" target="_blank">View PDF</a>
    <?php else: ?>
      <em>No PDF uploaded</em>
    <?php endif; ?>
  </div>
  <input type="file" name="pdf" accept="application/pdf">

  <button type="submit">Save Changes</button>
</form>

</body>
</html>
