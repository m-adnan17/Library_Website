-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 17, 2025 at 10:53 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `isbn` varchar(50) NOT NULL,
  `genre` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `cover` varchar(255) DEFAULT NULL,
  `pdf` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `title`, `author`, `isbn`, `genre`, `quantity`, `created_at`, `cover`, `pdf`, `description`) VALUES
(6, 'Soul', 'Olivia Wilson', '293r09e', 'fiction', 8, '2025-04-14 16:38:34', 'soul.jpg', 'soul.pdf', 'The book which is written by Olivia Wilson describe the personality of a young girl which is surviving through difficult times and the struggles that she faced.'),
(7, 'The Grave Secrets', 'Rex Munsee', '893002', 'fiction', 8, '2025-04-14 16:56:16', 'grave.jpeg', 'grave.pdf', 'This Book includes short tales and mystery and thriller stories which is a wonderful if you are a lover of thriller and mystery books.'),
(8, 'The Past is Rising', 'Kathryn Bywaters', '209452', 'fiction', 19, '2025-04-14 16:58:15', 'the past.jpg', 'past.pdf', 'The Past is Rising is a about witch who hunts the common people and drink their blood to keep her alive and young.');

-- --------------------------------------------------------

--
-- Table structure for table `borrowed_books`
--

CREATE TABLE `borrowed_books` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `borrowed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `returned_at` datetime DEFAULT NULL,
  `due_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `borrowed_books`
--

INSERT INTO `borrowed_books` (`id`, `user_id`, `book_id`, `borrowed_at`, `returned_at`, `due_date`) VALUES
(4, 8, 6, '2025-04-15 23:00:00', NULL, '2025-04-30'),
(20, 11, 8, '2025-04-16 21:46:36', NULL, '2025-04-23'),
(25, 13, 6, '2025-04-16 23:00:00', NULL, '2025-05-01'),
(26, 14, 7, '2025-04-16 23:00:00', NULL, '2025-05-01'),
(27, 14, 6, '2025-04-16 23:00:00', NULL, '2025-05-01'),
(29, 16, 7, '2025-04-16 23:00:00', NULL, '2025-05-01');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','user') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_expires` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `created_at`, `reset_token`, `reset_expires`) VALUES
(8, 'admin', 'admin@library.com', '$argon2id$v=19$m=65536,t=4,p=1$RjBFZnl1Qll4ZFViSGMyaA$rvbIsXXMpnQc4k/tFKIzAKP1Jg911M7wB7/o228NcQQ', 'admin', '2025-04-06 22:59:16', NULL, NULL),
(11, 'Jay', 'hopepo6066@dfesc.com', '$argon2id$v=19$m=65536,t=4,p=1$MThsRVdXZExLZWg1Ti5xYw$WjOCkylFLMc25TpWhynNvTGJOEJPjyz7rRtj+fuZ69w', 'user', '2025-04-14 17:07:32', NULL, NULL),
(12, 'khan', 'user@gmail.com', '$2y$10$pDeo647lMAcVZzYbqEsi8.SUmgcmUzf5GoYg24aeBniCw.Xowk2PO', 'user', '2025-04-16 21:49:42', NULL, NULL),
(13, 'Adnan_Khan', 'adnan@gmail.com', '$argon2id$v=19$m=65536,t=4,p=1$cUpPbGI5TTdIOEgzWksucg$n6Qzd4hFPK5bF/B99ptTxpSLenvBlgWEiBvlyhqBe4M', 'user', '2025-04-17 07:40:36', NULL, NULL),
(14, 'Mughal', 'mughal@gmail.com', '$argon2id$v=19$m=65536,t=4,p=1$RTk5SGZXUDRabE9BM2hvaQ$6ipPhoWNck9rYCos9MTWtcxPcTmfCfOCyz+77lbOYC4', 'user', '2025-04-17 08:06:06', NULL, NULL),
(16, 'adnanmughal', 'adnanm@gmail.com', '$argon2id$v=19$m=65536,t=4,p=1$MkQzci44QVRISHlYaXZYNg$AIgHYB6Lwfo+cn6qWphH3caxtsuTI44BVy8I/rXZaeg', 'user', '2025-04-17 08:33:54', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `isbn` (`isbn`);

--
-- Indexes for table `borrowed_books`
--
ALTER TABLE `borrowed_books`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `book_id` (`book_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `borrowed_books`
--
ALTER TABLE `borrowed_books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `borrowed_books`
--
ALTER TABLE `borrowed_books`
  ADD CONSTRAINT `borrowed_books_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `borrowed_books_ibfk_2` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
