<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

require 'database.php';

// Handle user creation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize inputs
    $username = trim($_POST['username']);
    $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
    $role = trim($_POST['role']);
    $password = $_POST['password'];

    // Validate inputs
    if (empty($username) || empty($email) || empty($role) || empty($password)) {
        echo "All fields are required!";
        exit();
    }

    // Hash the password securely
    $password_hash = password_hash($password, PASSWORD_BCRYPT);

    // Prepare the insert statement
    $stmt = $conn->prepare("INSERT INTO users (username, email, role, password) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $username, $email, $role, $password_hash);

    if ($stmt->execute()) {
        header("Location: user_management.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
