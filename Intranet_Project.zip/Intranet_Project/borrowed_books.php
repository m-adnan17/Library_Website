<?php
session_start();
require_once 'database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

$userId = $_SESSION['user_id'];

$stmt = $conn->prepare("
    SELECT b.title, b.author, bb.borrowed_at
    FROM borrowed_books bb
    JOIN books b ON bb.book_id = b.id
    WHERE bb.user_id = ?
");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
?>

<h2>Borrowed Books</h2>

<?php if (isset($_GET['success'])): ?>
  <p style="color: green;"><?= htmlspecialchars($_GET['success']) ?></p>
<?php endif; ?>

<table border="1">
  <tr>
    <th>Title</th>
    <th>Author</th>
    <th>Borrowed At</th>
  </tr>

  <?php while ($row = $result->fetch_assoc()) { ?>
    <tr>
      <td><?= htmlspecialchars($row['title']) ?></td>
      <td><?= htmlspecialchars($row['author']) ?></td>
      <td><?= $row['borrowed_at'] ?></td>
    </tr>
  <?php } ?>
</table>
