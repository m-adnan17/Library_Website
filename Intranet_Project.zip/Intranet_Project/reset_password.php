<?php
session_start();
require_once 'database.php';

// Check if token exists
if (!isset($_GET['token'])) {
    echo "<script>alert('Invalid or expired reset link.'); window.location.href='login.html';</script>";
    exit();
}

$token = $_GET['token'];

// Verify token and check expiration
$stmt = $conn->prepare("SELECT email FROM users WHERE reset_token = ? AND reset_expires > NOW()");
$stmt->bind_param("s", $token);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "<script>alert('Invalid or expired reset link.'); window.location.href='login.html';</script>";
    exit();
}

$user = $result->fetch_assoc();
$email = $user['email'];

// Handle new password submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newPassword = $_POST['password'];
    $confirmPassword = $_POST['confirm_password'];

    if (empty($newPassword) || empty($confirmPassword)) {
        echo "<script>alert('Please fill in all fields.');</script>";
    } elseif ($newPassword !== $confirmPassword) {
        echo "<script>alert('Passwords do not match.');</script>";
    } else {
        // Hash the new password
        $hashedPassword = password_hash($newPassword, PASSWORD_ARGON2ID);

        // Update password and remove token
        $stmt = $conn->prepare("UPDATE users SET password = ?, reset_token = NULL, reset_expires = NULL WHERE email = ?");
        $stmt->bind_param("ss", $hashedPassword, $email);
        $stmt->execute();

        echo "<script>alert('Password reset successful! You can now log in.'); window.location.href='login.html';</script>";
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reset Password - Library Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea, #764ba2);
            font-family: 'Roboto', sans-serif;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .reset-password-container {
            background: rgba(255, 255, 255, 0.95);
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
            max-width: 500px;
            width: 100%;
            animation: fadeIn 1s ease-in-out;
        }
        .reset-password-container h3 {
            font-weight: 700;
            margin-bottom: 20px;
            color: #333;
            text-align: center;
        }
        .form-label {
            font-weight: 500;
        }
        .btn-primary {
            background: linear-gradient(45deg, #667eea, #764ba2);
            border: none;
            font-size: 1.1rem;
            padding: 0.75rem;
            width: 100%;
        }
        .btn-primary:hover {
            opacity: 0.9;
        }
        .back-to-login {
            text-align: center;
            margin-top: 15px;
            font-size: 0.9rem;
        }
        .back-to-login a {
            text-decoration: none;
            color: #667eea;
            transition: color 0.3s;
        }
        .back-to-login a:hover {
            color: #764ba2;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
  <div class="reset-password-container">
    <h3>Reset Your Password</h3>
    <form action="reset_password.php?token=<?php echo htmlspecialchars($token); ?>" method="POST">
      <div class="mb-3">
        <label for="password" class="form-label">New Password:</label>
        <input type="password" class="form-control" name="password" placeholder="Enter your new password" required>
      </div>
      <div class="mb-3">
        <label for="confirm_password" class="form-label">Confirm New Password:</label>
        <input type="password" class="form-control" name="confirm_password" placeholder="Confirm your new password" required>
      </div>
      <button type="submit" class="btn btn-primary">Update Password</button>
    </form>
    <div class="back-to-login">
      <a href="login.html">Back to Login</a>
    </div>
  </div>
</body>
</html>
