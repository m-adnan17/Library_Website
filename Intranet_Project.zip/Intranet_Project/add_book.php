<?php
// Start session and include database connection
session_start();
require_once 'database.php';

// Restrict access to admins only
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $author = trim($_POST['author']);
    $isbn = trim($_POST['isbn']);
    $genre = trim($_POST['genre']);
    $quantity = intval($_POST['quantity']);

    // Validate input (you can expand this as needed)
    if ($title && $author && $isbn && $genre && $quantity >= 0) {
        $stmt = $conn->prepare("INSERT INTO books (title, author, isbn, genre, quantity) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssi", $title, $author, $isbn, $genre, $quantity);

        if ($stmt->execute()) {
            header("Location: view_books.php?message=Book added successfully.");
            exit();
        } else {
            $error = "Error adding book. Please try again.";
        }
    } else {
        $error = "Please fill in all fields correctly.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add New Book</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        h2 { color: #333; }
        form { max-width: 500px; }
        input[type="text"], input[type="number"] {
            width: 100%; padding: 10px; margin-bottom: 10px;
            border: 1px solid #ccc; border-radius: 4px;
        }
        button {
            padding: 10px 20px; background-color: #4CAF50;
            color: white; border: none; border-radius: 4px;
            cursor: pointer;
        }
        .error { color: red; }
        a { display: inline-block; margin-top: 15px; text-decoration: none; color: #555; }
    </style>
</head>
<body>
    <h2>Add New Book</h2>

    <?php if (!empty($error)): ?>
        <p class="error"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>

    <form method="POST" action="add_book.php">
        <label>Title:</label>
        <input type="text" name="title" required>

        <label>Author:</label>
        <input type="text" name="author" required>

        <label>ISBN:</label>
        <input type="text" name="isbn" required>

        <label>Genre:</label>
        <input type="text" name="genre" required>

        <label>Quantity:</label>
        <input type="number" name="quantity" min="0" required>

        <button type="submit">Add Book</button>
    </form>

    <a href="view_books.php">← Back to Book List</a>
</body>
</html>
