<?php
session_start();
require_once 'database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

$userId = $_SESSION['user_id'];

// Fetch user name
$stmt = $conn->prepare("SELECT username FROM users WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$stmt->bind_result($userName);
$stmt->fetch();
$stmt->close();

// Fetch 3 featured books
$featured = $conn->query("SELECT id, title, genre, cover FROM books ORDER BY RAND() LIMIT 3");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Library Home</title>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background: linear-gradient(135deg, #667eea, #567f38);
      color: #fff;
    }
    a {
      text-decoration: none;
      color: inherit;
    }
    .container {
      width: 90%;
      max-width: 1200px;
      margin: auto;
    }
    header {
      background: linear-gradient(135deg, #f3bc36, #764ba2);
      padding: 25px 0;
      color: #fff;
    }
    .navbar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
    }
    .logo {
      font-size: 1.5em;
      font-weight: bold;
      padding-left: 20px;
      display: flex;
      align-items: center;
    }
    .logo img {
      height: 40px;
      margin-right: 10px;
    }
    .search-container {
      display: flex;
      align-items: center;
      justify-content: center;
      flex: 1;
    }
    .search-container input[type="text"] {
      padding: 10px;
      border: none;
      border-radius: 3px;
      width: 300px;
    }
    .search-container button {
      padding: 10px 15px;
      margin-left: 10px;
      border: none;
      border-radius: 3px;
      background: linear-gradient(45deg, #667eea, #764ba2);
      color: #fff;
      cursor: pointer;
    }
    .user-actions {
      display: flex;
      align-items: center;
      gap: 15px;
      padding-right: 20px;
    }
    .user-actions span {
      font-weight: bold;
    }
    .user-actions button {
      padding: 10px 15px;
      border: none;
      border-radius: 3px;
      background-color: #fff;
      color: #764ba2;
      font-weight: bold;
      cursor: pointer;
    }
    .hero {
      background: url('library-bg.jpg') no-repeat center center/cover;
      text-align: center;
      padding: 100px 20px;
      position: relative;
    }
    .hero::before {
      content: "";
      position: absolute;
      top: 0; left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.4);
      z-index: 1;
    }
    .hero-content {
      position: relative;
      z-index: 2;
    }
    .hero h1 {
      font-size: 3em;
      margin-bottom: 20px;
    }
    .hero p {
      font-size: 1.2em;
      margin-bottom: 30px;
    }
    .hero .btn-group button {
      padding: 10px 20px;
      border: none;
      border-radius: 3px;
      margin: 0 10px;
      font-size: 1em;
      background-color: #f3bc36;
      color: #764ba2;
      cursor: pointer;
    }
    .features {
      padding: 60px 20px;
      background-color: #fff;
      text-align: center;
      color: #333;
    }
    .features h2 {
      margin-bottom: 40px;
      font-size: 2.5em;
    }
    .feature-items {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 20px;
    }
    .feature-item {
      background-color: #f9f9f9;
      padding: 20px;
      border-radius: 5px;
      width: 280px;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }
    .feature-item img {
      width: 100%;
      height: 400px;
      object-fit: cover;
      border-radius: 5px;
    }
    .feature-item h3 {
      margin-top: 10px;
      margin-bottom: 15px;
    }
    .feature-item p {
      margin: 0;
    }
    .feature-item form button {
      margin-top: 10px;
      padding: 10px 15px;
      border: none;
      border-radius: 3px;
      background-color: #667eea;
      color: #fff;
      cursor: pointer;
    }
    footer {
      background: linear-gradient(135deg, #667eea, #f3bc36);
      color: #fff;
      padding: 20px 0;
    }
    .footer-container {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      align-items: center;
      width: 90%;
      max-width: 1200px;
      margin: auto;
    }
    .footer-logo {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
    }
    .footer-logo img {
      height: 40px;
    }
  </style>
</head>
<body>

<!-- Navigation Bar -->
<header>
  <div class="container navbar">
    <div class="logo">
      <img src="logo.png" alt="Library Logo">
      Ocean library
    </div>
    <div class="search-container">
      <form action="search_results.php" method="GET">
        <input type="text" name="search" placeholder="Search books..." required>
        <button type="submit">Search</button>
      </form>
    </div>
    <div class="user-actions">
      <span>Welcome, <?= htmlspecialchars($userName) ?></span>
      <button onclick="location.href='logout.php'">Logout</button>
    </div>
  </div>
</header>

<!-- Hero Section -->
<section class="hero">
  <div class="hero-content container">
    <h1>Welcome back to Ocean Library</h1>
    <p>Access your borrowed books, explore collections, and more.</p>
    <div class="btn-group">
      <button onclick="location.href='user_dashboard.php'">View My Dashboard</button>
    </div>
  </div>
</section>

<!-- Featured Books Section -->
<section class="features">
  <div class="container">
    <h2>Featured Books</h2>
    <div class="feature-items">
      <?php while ($book = $featured->fetch_assoc()): ?>
        <div class="feature-item" onclick="window.location.href='book_details.php?id=<?= $book['id'] ?>'">
          <img src="uploads/covers/<?= htmlspecialchars($book['cover']) ?>" alt="<?= htmlspecialchars($book['title']) ?>">
          <h3><?= htmlspecialchars($book['title']) ?></h3>
          <p><?= htmlspecialchars($book['genre']) ?></p>
        </div>
      <?php endwhile; ?>
    </div>
  </div>
</section>

<!-- Footer Section -->
<footer>
  <div class="footer-container">
    <div class="footer-logo">
      <img src="logo.png" alt="Library Logo">
      <strong>Ocean Library</strong>
    </div>
    <div class="footer-about">
      <p>About Us: Dedicated to providing the best collection of literature and learning resources.</p>
    </div>
    <div class="footer-copy">
      <p>&copy; 2025 Library Management. All rights reserved.</p>
    </div>
  </div>
</footer>

</body>
</html>
