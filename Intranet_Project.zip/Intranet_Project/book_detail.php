<?php
require 'database.php';
$id = (int)$_GET['id'];
$book = $conn->query("SELECT * FROM featured_books WHERE id = $id")->fetch_assoc();
?>

<h2><?= htmlspecialchars($book['title']) ?></h2>
<img src="uploads/<?= $book['image_path'] ?>" alt="Cover" style="max-width:300px;">
<p><?= nl2br(htmlspecialchars($book['description'])) ?></p>
