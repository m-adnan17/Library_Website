<?php
// File: database.php
// Database connection parameters. Replace these with your actual credentials.
$servername   = "localhost";
$db_username  = "root"; // Default XAMPP username
$db_password  = "";     // Default XAMPP password is empty
$dbname       = "library_management"; // Database name

// Enable strict error reporting for MySQLi
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    // Create connection using MySQLi
    $conn = new mysqli($servername, $db_username, $db_password, $dbname);
    
    // Set charset to utf8mb4 to ensure proper encoding and enhanced security
    $conn->set_charset("utf8mb4");

    // Ensure the 'users' table exists, if not, create it
    $createUsersTable = "
    CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        email VARCHAR(100) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        role ENUM('admin', 'user') NOT NULL DEFAULT 'user',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    $conn->query($createUsersTable);

    // Ensure default admin user exists
    $admin_username = "admin";
    $admin_email = "admin@library.com";
    $admin_password = password_hash("Admin@123", PASSWORD_ARGON2ID); // Securely hashed password
    $admin_role = "admin";

    $checkAdmin = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $checkAdmin->bind_param("s", $admin_username);
    $checkAdmin->execute();
    $checkAdmin->store_result();

    if ($checkAdmin->num_rows === 0) {
        $insertAdmin = $conn->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
        $insertAdmin->bind_param("ssss", $admin_username, $admin_email, $admin_password, $admin_role);
        $insertAdmin->execute();
        $insertAdmin->close();
    }
    $checkAdmin->close();
} catch (Exception $e) {
    // Log detailed error message
    error_log($e->getMessage());
    // Display a generic error message to the user
    die("Database connection failed. Please try again later.");
}
?>
