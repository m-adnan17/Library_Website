<?php
session_start();
require_once 'database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

// Delete book
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $conn->prepare("SELECT cover, pdf FROM books WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($cover, $pdf);
    $stmt->fetch();
    if ($cover && file_exists("uploads/covers/$cover")) unlink("uploads/covers/$cover");
    if ($pdf && file_exists("uploads/pdfs/$pdf")) unlink("uploads/pdfs/$pdf");
    $stmt->close();

    $stmt = $conn->prepare("DELETE FROM books WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();

    header("Location: book_management.php");
    exit();
}

// Add new book
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_book'])) {
    $title = $_POST['title'];
    $author = $_POST['author'];
    $isbn = $_POST['isbn'];
    $genre = $_POST['genre'];
    $quantity = (int) $_POST['quantity'];

    $cover = $_FILES['cover']['name'];
    $pdf = $_FILES['pdf']['name'];

    $coverPath = "uploads/covers/" . basename($cover);
    $pdfPath = "uploads/pdfs/" . basename($pdf);

    move_uploaded_file($_FILES['cover']['tmp_name'], $coverPath);
    move_uploaded_file($_FILES['pdf']['tmp_name'], $pdfPath);

    $stmt = $conn->prepare("INSERT INTO books (title, author, isbn, genre, quantity, cover, pdf) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssiss", $title, $author, $isbn, $genre, $quantity, $cover, $pdf);
    $stmt->execute();
    $stmt->close();

    header("Location: book_management.php");
    exit();
}

// Fetch books
$books = [];
$result = $conn->query("SELECT * FROM books ORDER BY title ASC");
if ($result) {
    $books = $result->fetch_all(MYSQLI_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Book Management</title>
  <style>
    body { font-family: Arial; margin: 20px; background: #567f38; }
    h2 { color: #333; }
    table { width: 100%; border-collapse: collapse; margin-top: 20px; background: #fff; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
    th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
    th { background-color: #667eea; color: white; }
    form { background: #fff; padding: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); margin-bottom: 30px; border-radius: 5px; }
    input[type="text"], input[type="number"], input[type="file"] { width: calc(100% - 20px); padding: 10px; margin-bottom: 10px; border: 1px solid #ccc; border-radius: 4px; }
    .btn { padding: 8px 12px; background: #667eea; color: #fff; text-decoration: none; border-radius: 4px; display: inline-block; margin-right: 5px; }
    .btn:hover { background: #5567d2; }
    .actions { display: flex; gap: 10px; }
    img.thumb { width: 60px; height: auto; border-radius: 4px; }
  </style>
</head>
<body>

<h2>Book Management</h2>
<a href="admin_dashboard.php" class="btn">Back to Dashboard</a>

<form action="book_management.php" method="POST" enctype="multipart/form-data">
  <h3>Add New Book</h3>
  <input type="hidden" name="add_book" value="1">
  <input type="text" name="title" placeholder="Title" required>
  <input type="text" name="author" placeholder="Author" required>
  <input type="text" name="isbn" placeholder="ISBN" required>
  <input type="text" name="genre" placeholder="Genre" required>
  <input type="number" name="quantity" placeholder="Quantity" required>
  <label>Cover Image:</label>
  <input type="file" name="cover" accept="image/*" required>
  <label>PDF File:</label>
  <input type="file" name="pdf" accept="application/pdf" required>
  <button type="submit" class="btn">Add Book</button>
</form>

<h3>Existing Books</h3>
<table>
  <tr>
    <th>Cover</th><th>Title</th><th>Author</th><th>ISBN</th><th>Genre</th><th>Qty</th><th>PDF</th><th>Actions</th>
  </tr>
  <?php foreach ($books as $book): ?>
    <tr>
      <td>
        <?php if ($book['cover']): ?>
          <img src="uploads/covers/<?= htmlspecialchars($book['cover']) ?>" class="thumb">
        <?php endif; ?>
      </td>
      <td><?= htmlspecialchars($book['title']) ?></td>
      <td><?= htmlspecialchars($book['author']) ?></td>
      <td><?= htmlspecialchars($book['isbn']) ?></td>
      <td><?= htmlspecialchars($book['genre']) ?></td>
      <td><?= htmlspecialchars($book['quantity']) ?></td>
      <td>
        <?php if ($book['pdf']): ?>
          <a href="uploads/pdfs/<?= htmlspecialchars($book['pdf']) ?>" target="_blank">View PDF</a>
        <?php endif; ?>
      </td>
      <td class="actions">
        <a href="edit_book.php?id=<?= $book['id'] ?>" class="btn">Edit</a>
        <a href="?delete=<?= $book['id'] ?>" class="btn" onclick="return confirm('Delete this book?');">Delete</a>
      </td>
    </tr>
  <?php endforeach; ?>
</table>

</body>
</html>
