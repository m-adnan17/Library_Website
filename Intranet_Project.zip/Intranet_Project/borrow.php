<?php
session_start();
require_once 'database.php';

// Make sure the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html?error=Please log in to borrow books.");
    exit();
}

$user_id = $_SESSION['user_id'];

// Validate book_id from GET
if (!isset($_GET['book_id']) || !is_numeric($_GET['book_id'])) {
    die("Invalid request: Book ID is missing or not valid.");
}

$book_id = intval($_GET['book_id']);

// 🔒 Restrict to max 3 unreturned books
$checkLimit = $conn->prepare("SELECT COUNT(*) AS total FROM borrowed_books WHERE user_id = ? AND returned_at IS NULL");
$checkLimit->bind_param("i", $user_id);
$checkLimit->execute();
$limitResult = $checkLimit->get_result()->fetch_assoc();
$checkLimit->close();

if ($limitResult['total'] >= 3) {
    echo "<script>alert('You can only borrow up to 3 books at a time. Please return a book first.'); 
          window.location.href = 'user_dashboard.php';</script>";
    exit();
}

// ✅ Check if book exists and is available
$stmt = $conn->prepare("SELECT quantity FROM books WHERE id = ?");
$stmt->bind_param("i", $book_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Book not found.");
}

$book = $result->fetch_assoc();
if ($book['quantity'] <= 0) {
    die("Sorry, this book is currently unavailable.");
}
$stmt->close();

// 📅 Dates for borrowing
$borrowed_at = date("Y-m-d");
$due_date = date("Y-m-d", strtotime("+14 days")); // 2 weeks from now

// 🔁 Insert into borrowed_books
$stmt = $conn->prepare("INSERT INTO borrowed_books (user_id, book_id, borrowed_at, due_date) VALUES (?, ?, ?, ?)");
$stmt->bind_param("iiss", $user_id, $book_id, $borrowed_at, $due_date);
$stmt->execute();
$stmt->close();

// 🔄 Update quantity in books table
$stmt = $conn->prepare("UPDATE books SET quantity = quantity - 1 WHERE id = ?");
$stmt->bind_param("i", $book_id);
$stmt->execute();
$stmt->close();

// ✅ Redirect to user dashboard or borrowed books page
header("Location: user_dashboard.php");
exit();
?>
