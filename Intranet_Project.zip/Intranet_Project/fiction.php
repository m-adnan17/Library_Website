<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}
$username = $_SESSION['email'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Fiction Books</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            color: #333;
            margin: 0;
        }
        .container {
            width: 90%;
            max-width: 1200px;
            margin: auto;
            padding: 20px;
        }
        .header {
            background: #764ba2;
            color: #fff;
            padding: 15px;
            text-align: center;
        }
        .book-list {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
        }
        .book-item {
            background: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            width: 250px;
            margin: 20px;
            text-align: center;
        }
        .book-item img {
            width: 100%;
            height: 300px;
            object-fit: cover;
            border-radius: 5px;
        }
        .book-item h3 {
            margin: 10px 0;
        }
        .book-item p {
            padding: 0 10px;
            color: #555;
        }
        .book-item a {
            display: block;
            padding: 10px;
            background: #764ba2;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 10px;
        }
    </style>
</head>
<body>

<!-- Header -->
<div class="header">
    <h1>Fiction Books</h1>
</div>

<!-- Book List -->
<div class="container">
    <div class="book-list">
        <!-- Book 1 -->
        <div class="book-item">
            <img src="fiction_book1.jpg" alt="Fiction Book 1">
            <h3>Book Title 1</h3>
            <p>Author: Author Name</p>
            <a href="book_details.php?book_id=1">View Details</a>
        </div>
        <!-- Book 2 -->
        <div class="book-item">
            <img src="fiction_book2.jpg" alt="Fiction Book 2">
            <h3>Book Title 2</h3>
            <p>Author: Author Name</p>
            <a href="book_details.php?book_id=2">View Details</a>
        </div>
        <!-- Add more books similarly -->
    </div>
</div>

</body>
</html>
