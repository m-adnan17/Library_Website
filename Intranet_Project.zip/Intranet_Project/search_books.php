<?php
session_start();
require_once 'database.php';

// Redirect to login if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}
$user_id = $_SESSION['user_id'];

// Process Borrow Request
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['borrow_book'])) {
    $book_id = $_POST['book_id'];

    // Check how many books the user has already borrowed (limit 3)
    $stmt = $conn->prepare("SELECT COUNT(*) FROM loans WHERE user_id = ? AND returned = 0");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($borrowed_count);
    $stmt->fetch();
    $stmt->close();

    if ($borrowed_count >= 3) {
        echo "<script>alert('You can only borrow up to 3 books at a time.'); window.location.href='search_books.php';</script>";
        exit();
    }

    // Check available quantity
    $stmt = $conn->prepare("SELECT quantity FROM books WHERE id = ?");
    $stmt->bind_param("i", $book_id);
    $stmt->execute();
    $stmt->bind_result($quantity);
    $stmt->fetch();
    $stmt->close();

    if ($quantity > 0) {
        // Decrement book quantity
        $stmt = $conn->prepare("UPDATE books SET quantity = quantity - 1 WHERE id = ?");
        $stmt->bind_param("i", $book_id);
        $stmt->execute();
        $stmt->close();

        // Insert loan record with a due date (e.g., 14 days from now)
        $due_date = date('Y-m-d', strtotime("+14 days"));
        $stmt = $conn->prepare("INSERT INTO loans (user_id, book_id, due_date) VALUES (?, ?, ?)");
        $stmt->bind_param("iis", $user_id, $book_id, $due_date);
        $stmt->execute();
        $stmt->close();

        echo "<script>alert('Book borrowed successfully! Due date: $due_date'); window.location.href='search_books.php';</script>";
        exit();
    } else {
        echo "<script>alert('Sorry, this book is out of stock.'); window.location.href='search_books.php';</script>";
        exit();
    }
}

// Handle search query (if any)
$search_query = "";
if (isset($_GET['search'])) {
    $search_query = $_GET['search'];
    $stmt = $conn->prepare("SELECT id, title, author, genre, quantity FROM books WHERE title LIKE ? OR author LIKE ? OR genre LIKE ?");
    $search_param = "%" . $search_query . "%";
    $stmt->bind_param("sss", $search_param, $search_param, $search_param);
    $stmt->execute();
    $books_result = $stmt->get_result();
    $stmt->close();
} else {
    // Default: show all books with quantity > 0
    $books_result = $conn->query("SELECT id, title, author, genre, quantity FROM books WHERE quantity > 0");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Search & Borrow Books - Library Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: #fff;
        }
        .navbar {
            background: rgba(0, 0, 0, 0.85);
            padding: 10px;
        }
        .container {
            margin-top: 30px;
        }
        .hero {
            text-align: center;
            margin-bottom: 30px;
        }
        .card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            padding: 20px;
            color: #333;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
        }
        .table thead {
            background: #667eea;
            color: #fff;
        }
    </style>
</head>
<body>
    <div id="navbar-placeholder"></div>
    <div class="container">
        <div class="hero">
            <h2>Search & Borrow Books</h2>
            <form method="GET" class="d-flex justify-content-center mb-4">
                <input type="text" name="search" class="form-control w-50 me-2" placeholder="Search by title, author, or genre" value="<?php echo htmlspecialchars($search_query); ?>">
                <button type="submit" class="btn btn-primary">Search</button>
            </form>
        </div>
        <div class="card">
            <h4>Available Books</h4>
            <table class="table table-striped table-hover mt-3">
                <thead>
                    <tr>
                        <th>Title</th>
                        <t
