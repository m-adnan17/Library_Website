<?php
session_start();
require_once 'database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);

    if (empty($email)) {
        echo "<script>alert('Please enter your email.'); window.location.href='forgot_password.php';</script>";
        exit();
    }

    // Check if email exists in the database
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 0) {
        echo "<script>alert('No account found with this email.'); window.location.href='forgot_password.php';</script>";
        exit();
    }

    // Generate a unique token
    $token = bin2hex(random_bytes(50));

    // Store token in the database (for security, add expiry time)
    $stmt = $conn->prepare("UPDATE users SET reset_token = ?, reset_expires = DATE_ADD(NOW(), INTERVAL 30 MINUTE) WHERE email = ?");
    $stmt->bind_param("ss", $token, $email);
    $stmt->execute();

    // Send email with reset link
    $resetLink = "http://localhost/reset_password.php?token=$token";
    $subject = "Password Reset Request";
    $message = "Click the link below to reset your password:\n\n$resetLink\n\nThis link will expire in 30 minutes.";
    $headers = "From: no-reply@yourwebsite.com";

    // Use mail() function (Make sure mail is enabled in XAMPP)
    mail($email, $subject, $message, $headers);

    echo "<script>alert('A password reset link has been sent to your email.'); window.location.href='login.html';</script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Forgot Password - Library Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea, #567f38);
            font-family: 'Roboto', sans-serif;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .forgot-password-container {
            background: rgba(255, 255, 255, 0.95);
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
            max-width: 500px;
            width: 100%;
            animation: fadeIn 1s ease-in-out;
        }
        .forgot-password-container h3 {
            font-weight: 700;
            margin-bottom: 20px;
            color: #333;
            text-align: center;
        }
        .form-label {
            font-weight: 500;
        }
        .btn-primary {
            background: linear-gradient(45deg, #667eea, #764ba2);
            border: none;
            font-size: 1.1rem;
            padding: 0.75rem;
            width: 100%;
        }
        .btn-primary:hover {
            opacity: 0.9;
        }
        .back-to-login {
            text-align: center;
            margin-top: 15px;
            font-size: 0.9rem;
        }
        .back-to-login a {
            text-decoration: none;
            color: #667eea;
            transition: color 0.3s;
        }
        .back-to-login a:hover {
            color: #764ba2;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
  <div class="forgot-password-container">
    <h3>Forgot Password</h3>
    <form action="forgot_password.php" method="POST">
      <div class="mb-3">
        <label for="email" class="form-label">Enter your email:</label>
        <input type="email" class="form-control" name="email" placeholder="Enter your registered email" required>
      </div>
      <button type="submit" class="btn btn-primary">Reset Password</button>
    </form>
    <div class="back-to-login">
      <a href="login.html">Back to Login</a>
    </div>
  </div>
</body>
</html>
