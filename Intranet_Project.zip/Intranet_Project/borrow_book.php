<?php
session_start();
require_once 'database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

$userId = $_SESSION['user_id'];
$bookId = intval($_POST['book_id'] ?? 0);

// Check book exists and is available
$check = $conn->prepare("SELECT quantity FROM books WHERE id = ?");
$check->bind_param("i", $bookId);
$check->execute();
$book = $check->get_result()->fetch_assoc();

if ($book && $book['quantity'] > 0) {
    // Insert into borrowed_books table
    $insert = $conn->prepare("INSERT INTO borrowed_books (user_id, book_id) VALUES (?, ?)");
    $insert->bind_param("ii", $userId, $bookId);
    $insert->execute();

    // Decrease quantity in books table
    $update = $conn->prepare("UPDATE books SET quantity = quantity - 1 WHERE id = ?");
    $update->bind_param("i", $bookId);
    $update->execute();

    header("Location: borrowed_books.php?success=Book borrowed successfully");
} else {
    header("Location: books.php?error=Book not available");
}
exit();
