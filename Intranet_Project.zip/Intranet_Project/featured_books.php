<?php
session_start();
require_once 'database.php';

// Check if user is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_FILES["cover_image"])) {
    $title = $_POST["title"];
    $author = $_POST["author"];
    $genre = $_POST["genre"];
    $description = $_POST["description"];

    // Image upload handling
    $target_dir = "uploads/";
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }
    $target_file = $target_dir . basename($_FILES["cover_image"]["name"]);
    move_uploaded_file($_FILES["cover_image"]["tmp_name"], $target_file);

    $stmt = $conn->prepare("INSERT INTO featured_books (title, author, genre, description, image_path) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $title, $author, $genre, $description, $target_file);
    $stmt->execute();
    $stmt->close();

    header("Location: featured_books.php?success=1");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Featured Books</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body { font-family: Arial, sans-serif; background: #f0f0f0; padding: 40px; }
        .form-container { background: #fff; padding: 30px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1); max-width: 700px; margin: auto; }
        h2 { text-align: center; margin-bottom: 30px; }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Add a Featured Book</h2>
    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success">Book successfully added!</div>
    <?php endif; ?>
    <form action="featured_books.php" method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label class="form-label">Book Title</label>
            <input type="text" name="title" class="form-control" required />
        </div>
        <div class="mb-3">
            <label class="form-label">Author</label>
            <input type="text" name="author" class="form-control" required />
        </div>
        <div class="mb-3">
            <label class="form-label">Genre</label>
            <input type="text" name="genre" class="form-control" required />
        </div>
        <div class="mb-3">
            <label class="form-label">Short Description</label>
            <textarea name="description" class="form-control" rows="3" required></textarea>
        </div>
        <div class="mb-3">
            <label class="form-label">Cover Image</label>
            <input type="file" name="cover_image" class="form-control" accept="image/*" required />
        </div>
        <button type="submit" class="btn btn-primary">Add Book</button>
    </form>
</div>

</body>
</html>
