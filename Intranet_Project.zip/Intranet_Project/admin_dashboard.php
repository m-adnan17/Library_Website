<?php
session_start();
require_once 'database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit();
}

// Fetch analytics
$totalUsers = $conn->query("SELECT COUNT(*) AS total FROM users WHERE role = 'user'")->fetch_assoc()['total'];
$totalBooks = $conn->query("SELECT SUM(quantity) AS total FROM books")->fetch_assoc()['total'];
$totalTitles = $conn->query("SELECT COUNT(*) AS total FROM books")->fetch_assoc()['total'];
$totalBorrowed = $conn->query("SELECT COUNT(*) AS total FROM borrowed_books WHERE returned_at IS NULL")->fetch_assoc()['total'];
$totalReturned = $conn->query("SELECT COUNT(*) AS total FROM borrowed_books WHERE returned_at IS NOT NULL")->fetch_assoc()['total'];

$currentPage = basename($_SERVER['PHP_SELF']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Admin Dashboard</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      background: #fff;
      color: #333;
    }

    header {
      background-color: #567f38;
      color: white;
      padding: 20px;
      text-align: center;
      position: relative;
    }

    nav {
      background-color: #283593;
      display: flex;
      justify-content: center;
      padding: 15px;
    }

    nav a {
      color: white;
      text-decoration: none;
      margin: 0 15px;
      padding: 10px 20px;
      border-radius: 5px;
      font-weight: bold;
      transition: background 0.3s;
    }

    nav a:hover,
    nav a.active {
      background-color: #5c6bc0;
    }

    .logout-btn {
      position: absolute;
      top: 20px;
      right: 20px;
      background-color: #e74c3c;
      color: white;
      border: none;
      padding: 10px 16px;
      border-radius: 4px;
      cursor: pointer;
    }

    .logout-btn:hover {
      background-color: #c0392b;
    }

    .container {
      padding: 40px 30px;
      max-width: 1000px;
      margin: auto;
    }

    .dashboard-boxes {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
      justify-content: center;
      margin-bottom: 40px;
    }

    .box {
      background-color: white;
      border-radius: 8px;
      padding: 20px;
      width: 200px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      text-align: center;
      transition: transform 0.3s;
    }

    .box:hover {
      transform: translateY(-5px);
    }

    .box h3 {
      margin: 0;
      font-size: 1.1em;
      color: #555;
    }

    .box p {
      font-size: 2em;
      margin-top: 10px;
      font-weight: bold;
      color: #3f51b5;
    }

    h2 {
      text-align: center;
      margin-bottom: 20px;
      color: #444;
    }

    footer {
      text-align: center;
      padding: 20px;
      font-size: 0.9em;
      color: #999;
    }
  </style>
</head>
<body>

<header>
  <h1>Admin Dashboard</h1>
  <form action="logout.php" method="post" style="display:inline;">
    <button class="logout-btn" type="submit">Logout</button>
  </form>
</header>

<nav>
  <a href="book_management.php" class="<?= $currentPage === 'book_management.php' ? 'active' : ''; ?>">Book Management</a>
  <a href="user_management.php" class="<?= $currentPage === 'user_management.php' ? 'active' : ''; ?>">User Management</a>
  <a href="borrowed_logs.php" class="btn">Borrowed Logs</a>
</nav>

<div class="container">
  <h2>Quick Analytics</h2>
  <div class="dashboard-boxes">
    <div class="box">
      <h3>Total Users</h3>
      <p><?= $totalUsers ?></p>
    </div>
    <div class="box">
      <h3>Total Books</h3>
      <p><?= $totalTitles ?></p>
    </div>
    <div class="box">
      <h3>Total Copies</h3>
      <p><?= $totalBooks ?></p>
    </div>
    <div class="box">
      <h3>Borrowed</h3>
      <p><?= $totalBorrowed ?></p>
    </div>
    <div class="box">
      <h3>Returned</h3>
      <p><?= $totalReturned ?></p>
    </div>
  </div>

  
</div>

<footer>
  &copy; <?= date('Y') ?> Library Management System | All rights reserved.
</footer>

</body>
</html>
