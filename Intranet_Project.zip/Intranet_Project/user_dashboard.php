<?php
session_start();
require_once 'database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.html");
    exit();
}

$userId = $_SESSION['user_id'];

// Return Book Logic
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['return_id'])) {
    $borrowId = intval($_POST['return_id']);
    $bookId = intval($_POST['return_book_id']);

    $return = $conn->prepare("UPDATE borrowed_books SET returned_at = NOW() WHERE id = ? AND user_id = ?");
    $return->bind_param("ii", $borrowId, $userId);
    $return->execute();

    if ($return->affected_rows > 0) {
        $update = $conn->prepare("UPDATE books SET quantity = quantity + 1 WHERE id = ?");
        $update->bind_param("i", $bookId);
        $update->execute();

        $success = "Book returned successfully.";
    } else {
        $error = "Could not return book.";
    }
}
// Clear Returned Book History
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['clear_history'])) {
    $delete = $conn->prepare("DELETE FROM borrowed_books WHERE user_id = ? AND returned_at IS NOT NULL");
    $delete->bind_param("i", $userId);
    $delete->execute();
    if ($delete->affected_rows > 0) {
        $success = "Returned book history cleared successfully.";
    } else {
        $error = "No returned books to clear.";
    }
}



// Fetch Borrowed Books
$stmt = $conn->prepare("
    SELECT bb.id AS borrow_id, b.id AS book_id, b.title, b.author, b.cover, b.pdf, bb.borrowed_at, bb.due_date, bb.returned_at
    FROM borrowed_books bb
    JOIN books b ON bb.book_id = b.id
    WHERE bb.user_id = ?
    ORDER BY bb.borrowed_at DESC
");
$stmt->bind_param("i", $userId);
$stmt->execute();
$borrowed = $stmt->get_result();

// Fetch available books
$searchTerm = "";
if (isset($_GET['search']) && !empty(trim($_GET['search']))) {
    $searchTerm = "%" . trim($_GET['search']) . "%";
    $stmt = $conn->prepare("SELECT * FROM books WHERE (title LIKE ? OR author LIKE ? OR genre LIKE ?) AND quantity > 0");
    $stmt->bind_param("sss", $searchTerm, $searchTerm, $searchTerm);
} else {
    $stmt = $conn->prepare("SELECT * FROM books WHERE quantity > 0");
}
$stmt->execute();
$availableBooks = $stmt->get_result();

// Borrow limit
$checkLimit = $conn->prepare("SELECT COUNT(*) AS total FROM borrowed_books WHERE user_id = ? AND returned_at IS NULL");
$checkLimit->bind_param("i", $userId);
$checkLimit->execute();
$borrowCount = $checkLimit->get_result()->fetch_assoc()['total'];
$checkLimit->close();

$limitReached = $borrowCount >= 3;
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Dashboard</title>
    <style>
        body { font-family: Arial; padding: 20px; background: linear-gradient(135deg, #567f38, #764ba2); color: #fff; }
        table { width: 100%; background: #fff; color: #333; border-collapse: collapse; margin: 30px auto; box-shadow: 0 0 10px rgba(0,0,0,0.2); }
        th, td { padding: 12px; border: 1px solid #ddd; text-align: center; }
        th { background-color: #f4f4f4; }
        .cover-img { height: 100px; border-radius: 4px; }
        .read-btn { background: #764ba2; color: white; padding: 10px 12px; border: none; border-radius: 4px; text-decoration: none; display: inline-block; }
        .read-btn:hover { background: #667eea; }
        .top-nav { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .logout-btn { background-color: #e74c3c; color: white; padding: 10px 16px; border: none; border-radius: 4px; cursor: pointer; }
        .nav-btn { background-color: #3498db; color: white; padding: 10px 16px; border: none; border-radius: 4px; text-decoration: none; cursor: pointer; }
        .success { color: limegreen; text-align: center; }
        .error { color: red; text-align: center; }
        form.search-bar { text-align: center; margin-top: 30px; }
        form.search-bar input[type="text"] { padding: 8px; width: 300px; border-radius: 4px; border: none; }
        form.search-bar button { padding: 8px 16px; background: #764ba2; color: white; border: none; border-radius: 4px; cursor: pointer; }
    </style>
</head>
<body>

<div class="top-nav">
    <h1>User Dashboard</h1>
    <div>
        <a href="home.php" class="nav-btn">Home</a>
        <form method="POST" action="logout.php" style="display:inline;">
            <button class="logout-btn">Logout</button>
        </form>
    </div>
</div>
<!-- 🔍 Search Bar -->
<div style="text-align: center; margin-top: 20px; margin-bottom: 20px;">
  <form method="GET" action="" style="display: inline-block;">
    <input type="text" name="search" placeholder="Search by title, author, or genre" required 
           style="padding: 10px; width: 300px; border-radius: 5px; border: 1px solid #ccc;">
    <button type="submit" 
            style="padding: 10px 15px; border: none; background: #3498db; color: white; border-radius: 5px; cursor: pointer;">
      Search
    </button>
  </form>
</div>


<p style="text-align:center; font-size:1.1em;">
    <?= $limitReached ? "<span style='color:red; font-weight:bold;'>You have reached the borrowing limit (3 books).</span>" : "<span style='color:limegreen;'>You have borrowed $borrowCount of 3 allowed books.</span>" ?>
</p>

<?php if (isset($success)): ?><p class="success"><?= $success ?></p><?php endif; ?>
<?php if (isset($error)): ?><p class="error"><?= $error ?></p><?php endif; ?>

    <!-- Clear History Button -->
<div style="text-align: center; margin-top: 10px;">
  <form method="POST" onsubmit="return confirm('Are you sure you want to clear your returned book history?');">
    <input type="hidden" name="clear_history" value="1">
    <button type="submit" style="padding: 10px 18px; background: #e67e22; color: white; border: none; border-radius: 5px; cursor: pointer;">
      Clear Returned Book History
    </button>
  </form>
</div>


<h2>My Borrowed Books</h2>
<table>
    <tr>
        <th>Cover</th><th>Title</th><th>Author</th><th>Borrowed At</th><th>Due Date</th><th>Returned At</th><th>Overdue</th><th>PDF</th><th>Return</th>
    </tr>
    <?php while ($row = $borrowed->fetch_assoc()): ?>
        <?php $isOverdue = !$row['returned_at'] && strtotime($row['due_date']) < time(); ?>
        <tr>
            <td><?= $row['cover'] ? "<img src='uploads/covers/{$row['cover']}' class='cover-img'>" : "No Cover" ?></td>
            <td><?= htmlspecialchars($row['title']) ?></td>
            <td><?= htmlspecialchars($row['author']) ?></td>
            <td><?= $row['borrowed_at'] ?></td>
            <td><?= $row['due_date'] ?></td>
            <td><?= $row['returned_at'] ?? '—' ?></td>
            <td><?= $row['returned_at'] ? "<span style='color:green;'>No</span>" : ($isOverdue ? "<span style='color:red;'>Yes</span>" : "Pending") ?></td>
            <td>
                <?php if (!$row['returned_at'] && !empty($row['pdf'])): ?>
                    <a href="uploads/pdfs/<?= htmlspecialchars($row['pdf']) ?>" class="read-btn" target="_blank">Read Online</a>
                <?php elseif ($row['returned_at']): ?>
                    <span style="color:#999;">Returned</span>
                <?php else: ?>
                    <span style="color:#999;">No PDF</span>
                <?php endif; ?>
            </td>
            <td>
                <?php if (!$row['returned_at']): ?>
                    <form method="POST">
                        <input type="hidden" name="return_id" value="<?= $row['borrow_id'] ?>">
                        <input type="hidden" name="return_book_id" value="<?= $row['book_id'] ?>">
                        <button type="submit">Return</button>
                    </form>
                <?php else: ?>
                    <span style="color:green;">✔</span>
                <?php endif; ?>
            </td>
        </tr>
    <?php endwhile; ?>
</table>



<!-- 📚 Available Books -->
<h2 style="text-align:center;">Available Books</h2>
<table>
    <tr><th>Cover</th><th>Title</th><th>Author</th><th>Genre</th><th>Quantity</th><th>Action</th></tr>
    <?php while ($book = $availableBooks->fetch_assoc()): ?>
        <tr>
            <td><?= $book['cover'] ? "<img src='uploads/covers/{$book['cover']}' class='cover-img'>" : "No Cover" ?></td>
            <td><?= htmlspecialchars($book['title']) ?></td>
            <td><?= htmlspecialchars($book['author']) ?></td>
            <td><?= htmlspecialchars($book['genre']) ?></td>
            <td><?= $book['quantity'] ?></td>
            <td>
                <?php if (!$limitReached): ?>
                    <form action="borrow.php" method="GET">
                        <input type="hidden" name="book_id" value="<?= $book['id'] ?>">
                        <button type="submit">Borrow</button>
                    </form>
                <?php else: ?>
                    <span style="color:red;">Limit Reached</span>
                <?php endif; ?>
            </td>
        </tr>
    <?php endwhile; ?>
</table>

</body>
</html>
