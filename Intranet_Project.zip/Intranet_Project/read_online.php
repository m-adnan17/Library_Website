<?php
session_start();
require_once 'database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

if (isset($_GET['book_id'])) {
    $book_id = intval($_GET['book_id']);

    // Get file path from DB
    $stmt = $conn->prepare("SELECT title, file_path FROM books WHERE id = ?");
    $stmt->bind_param("i", $book_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($book = $result->fetch_assoc()) {
        $filePath = $book['file_path']; // e.g., "uploads/books/mybook.pdf"

        if (file_exists($filePath)) {
            // You can also use an iframe viewer instead of download
            header("Content-Type: application/pdf");
            header("Content-Disposition: inline; filename=\"" . basename($filePath) . "\"");
            readfile($filePath);
            exit();
        } else {
            echo "<script>alert('Book file not found.'); window.history.back();</script>";
        }
    } else {
        echo "<script>alert('Book not found.'); window.history.back();</script>";
    }
} else {
    echo "<script>alert('Invalid request.'); window.history.back();</script>";
}
?>
